package com.sapient.controller;

import com.sapient.model.Brand;
import com.sapient.model.Color;
import com.sapient.service.BrandService;
import com.sapient.service.colorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/colors")
public class ColorController {
    @Autowired
   colorService colorService;

    @GetMapping
    public ResponseEntity<List<Color>> findAll(){
        List<Color> colorList=colorService.findAll();
        return new ResponseEntity<List<Color>>(colorList, HttpStatus.OK);
    }
}
