package com.sapient.controller;

import com.sapient.model.Color;
import com.sapient.model.ProductCategory;
import com.sapient.service.ProductCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/ProductCategories")
public class ProductCategoryController {
@Autowired
ProductCategoryService productCategoryService;
@GetMapping
public ResponseEntity<List<ProductCategory>> findAll(){
    List<ProductCategory> productCategoryList=productCategoryService.findAll();
    return new ResponseEntity<List<ProductCategory>>(productCategoryList, HttpStatus.OK);
}
}
