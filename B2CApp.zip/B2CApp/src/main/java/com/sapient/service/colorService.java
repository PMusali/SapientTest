package com.sapient.service;

import com.sapient.model.Brand;
import com.sapient.model.Color;
import com.sapient.repository.BrandRepository;
import com.sapient.repository.ColorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class colorService {
    @Autowired
    ColorRepository colorRepository;
    public List<Color> findAll(){

        return colorRepository.findAll();
    }

}

