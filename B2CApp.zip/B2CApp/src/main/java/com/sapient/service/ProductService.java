package com.sapient.service;

import com.sapient.model.Product;
import com.sapient.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;
enum GroupBy {

    BRAND("brand"), COLOR("color"), SIZE("size");
    String value;

    GroupBy(String name) {
        value = name;
    }

    String getValue() {
        return value;
    }
}
@Service
public class ProductService {

    @Autowired
    ProductRepository productRepository;


    public List<Product> findAll() {
        return productRepository.findAll();
    }


    public List<Product> getProducts(String groupByValue, String actualvalue) {
        GroupBy groupBy = GroupBy.valueOf(groupByValue.toUpperCase());
        switch (groupBy) {
            case BRAND:
                return productRepository.findByBrandId(Integer.valueOf(actualvalue));
            case COLOR:
                return productRepository.findByColorId(Integer.valueOf(actualvalue));
            case SIZE:
                return productRepository.findBySize(actualvalue);
            default:
                return null;
        }
    }


}
