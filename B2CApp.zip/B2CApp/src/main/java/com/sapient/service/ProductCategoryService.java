package com.sapient.service;

import com.sapient.model.Color;
import com.sapient.model.ProductCategory;
import com.sapient.repository.ProductCategoryReposotory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductCategoryService {
    @Autowired
    ProductCategoryReposotory productCategoryReposotory;
    public List<ProductCategory> findAll(){

        return productCategoryReposotory.findAll();
    }
}
