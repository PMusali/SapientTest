package com.sapient.exception;

public class B2CException extends RuntimeException {

    public B2CException(String message){
        super(message);
    }
}
