package com.sapient.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*@Configuration
@EnableSwagger2
public class ApiOpenSpecification {
@Bean
public Docket api(){
    return new Docket(DocumentationType.SWAGGER_2)
            .select()
            .apis(RequestHandlerSelectors.basePackage("com.sapient.B2CApp"))
            .paths(PathSelectors.any())
            .build();
}
}*/
